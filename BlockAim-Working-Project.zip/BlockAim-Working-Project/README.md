# BlockAim Trainer — Android project

This is a **native Android app project** with working offline aim-practice logic, not a static screenshot or HTML-only mockup.

## What works
- 30-second practice round
- Randomly positioned targets
- Tap detection, score, hits/shots and accuracy
- Start/restart button
- Runs offline after installation

## What it is not
This version is a standalone aim trainer. It does not draw over other apps, read game screens, automate taps, or provide live game moves. It is a real first build of the BlockAim app concept, designed to be safe and testable as a standalone app.

## Build an APK in GitHub (phone-friendly)
1. Upload the contents of this folder to your GitHub repository (keep the folder structure).
2. Open the repository's **Actions** tab.
3. Select **Build BlockAim APK** and tap **Run workflow** (or push to `main`/`master`).
4. When the run finishes, open it and download the `BlockAim-debug-apk` artifact.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.
6. Install the APK on your Android phone. Android may ask you to allow installs from the browser/file manager you used.

The workflow uses GitHub-hosted build machines and uploads the APK as an artifact. GitHub account usage limits and terms apply.

## Project details
- Package: `com.blockaim.trainer`
- Minimum Android: Android 6.0 (API 23)
- Target SDK: 35
- Build: Gradle + Android Gradle Plugin
