package com.blockaim.trainer

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.hypot
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var gameView: AimTrainerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 17, 31)
        window.navigationBarColor = Color.rgb(8, 17, 31)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        gameView = AimTrainerView(this)
        setContentView(gameView)
    }
    override fun onResume() { super.onResume(); if (::gameView.isInitialized) gameView.resumeClock() }
    override fun onPause() { if (::gameView.isInitialized) gameView.pauseClock(); super.onPause() }
}

private class AimTrainerView(activity: Activity) : View(activity) {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(8, 17, 31) }
    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(17, 30, 49) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 42f; typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD) }
    private val subText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(164, 184, 207); textSize = 25f }
    private val cyan = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(57, 230, 208); style = Paint.Style.FILL }
    private val targetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 95, 112); style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 5f }
    private val buttonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(28, 190, 174) }
    private val handler = Handler(Looper.getMainLooper())
    private var score = 0
    private var shots = 0
    private var hits = 0
    private var seconds = 30
    private var running = false
    private var targetX = 0f
    private var targetY = 0f
    private var targetR = 44f
    private var message = "Tap START to begin"
    private var button = RectF()
    private var area = RectF()
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            seconds--
            if (seconds <= 0) { seconds = 0; running = false; message = "Round complete! Tap START to play again" }
            invalidate()
            if (running) handler.postDelayed(this, 1000)
        }
    }

    fun resumeClock() { if (running) { handler.removeCallbacks(tick); handler.postDelayed(tick, 1000) } }
    fun pauseClock() { handler.removeCallbacks(tick) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        val pad = width * 0.06f
        text.textSize = width * 0.085f
        canvas.drawText("BLOCKAIM", pad, height * 0.09f, text)
        subText.textSize = width * 0.034f
        canvas.drawText("AIM TRAINER  •  OFFLINE PRACTICE", pad, height * 0.125f, subText)

        val top = height * 0.16f
        val bottom = height * 0.28f
        canvas.drawRoundRect(pad, top, width - pad, bottom, 24f, 24f, panel)
        text.textSize = width * 0.055f
        canvas.drawText("SCORE  $score", pad * 1.5f, top + (bottom-top)*0.42f, text)
        subText.textSize = width * 0.04f
        canvas.drawText("HITS $hits / SHOTS $shots", pad * 1.5f, top + (bottom-top)*0.76f, subText)
        canvas.drawText("TIME  ${seconds}s", width - pad * 1.5f - subText.measureText("TIME  ${seconds}s"), top + (bottom-top)*0.55f, subText)

        area.set(pad, height * 0.32f, width-pad, height * 0.76f)
        canvas.drawRoundRect(area, 28f, 28f, panel)
        if (running) {
            canvas.drawCircle(targetX, targetY, targetR, targetPaint)
            canvas.drawCircle(targetX, targetY, targetR * 0.62f, ring)
            canvas.drawCircle(targetX, targetY, targetR * 0.2f, cyan)
            // subtle crosshair marks
            val old = ring.strokeWidth
            ring.strokeWidth = 3f
            canvas.drawLine(targetX-targetR-13, targetY, targetX-targetR+3, targetY, ring)
            canvas.drawLine(targetX+targetR-3, targetY, targetX+targetR+13, targetY, ring)
            canvas.drawLine(targetX, targetY-targetR-13, targetX, targetY-targetR+3, ring)
            canvas.drawLine(targetX, targetY+targetR-3, targetX, targetY+targetR+13, ring)
            ring.strokeWidth = old
        } else {
            text.textSize = width * 0.052f
            val lines = if (seconds == 0) listOf("ROUND FINISHED", "Score: $score  •  Accuracy: ${accuracy()}%") else listOf("READY WHEN YOU ARE", "Tap START, then hit the moving targets")
            lines.forEachIndexed { i, line -> canvas.drawText(line, (width - text.measureText(line)) / 2f, height * (0.48f + i * 0.055f), text) }
        }
        button.set(pad, height * 0.81f, width-pad, height * 0.9f)
        canvas.drawRoundRect(button, 24f, 24f, buttonPaint)
        text.textSize = width * 0.055f
        val label = if (running) "PRACTICE RUNNING" else "START / RESTART"
        canvas.drawText(label, (width-text.measureText(label))/2f, button.centerY()+text.textSize*0.35f, text)
        subText.textSize = width * 0.031f
        val footer = "Every hit = 1 point  •  Accuracy ${accuracy()}%"
        canvas.drawText(footer, (width-subText.measureText(footer))/2f, height*0.95f, subText)
    }

    private fun accuracy(): Int = if (shots == 0) 0 else (hits * 100 / shots)
    private fun spawnTarget() {
        val minX = area.left + targetR + 12f
        val maxX = area.right - targetR - 12f
        val minY = area.top + targetR + 12f
        val maxY = area.bottom - targetR - 12f
        targetX = if (maxX > minX) Random.nextFloat() * (maxX-minX) + minX else width/2f
        targetY = if (maxY > minY) Random.nextFloat() * (maxY-minY) + minY else height/2f
    }
    private fun start() {
        score = 0; shots = 0; hits = 0; seconds = 30; running = true
        message = "Hit as many targets as you can"
        targetR = (width * 0.075f).coerceIn(28f, 55f)
        area.set(width*0.06f, height*0.32f, width*0.94f, height*0.76f)
        spawnTarget(); handler.removeCallbacks(tick); handler.postDelayed(tick, 1000); invalidate()
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val x = event.x; val y = event.y
        if (button.contains(x,y)) { start(); return true }
        if (running && area.contains(x,y)) {
            shots++
            if (hypot((x-targetX).toDouble(), (y-targetY).toDouble()) <= targetR) { hits++; score++; spawnTarget() }
            invalidate()
        }
        return true
    }
}
