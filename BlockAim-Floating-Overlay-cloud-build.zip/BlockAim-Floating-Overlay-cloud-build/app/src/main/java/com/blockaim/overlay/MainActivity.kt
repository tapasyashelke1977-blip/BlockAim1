package com.blockaim.overlay

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24); setBackgroundColor(Color.rgb(16,20,38)) }
        root.addView(TextView(this).apply { text = "BlockAim GUI"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 10, 0, 24) })
        root.addView(TextView(this).apply { text = "Floating GUI prototype"; textSize = 16f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, 16) })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf("Enable GUI", "Aim Assist (visual only)", "Show Target (visual only)", "Smooth Aim (visual only)", "Mob Filter (visual only)", "Show Status", "Compact Mode", "Save Settings").forEach { label ->
            val cb = CheckBox(this).apply { text = label; textSize = 16f; setTextColor(Color.WHITE); buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(91,140,255)); setPadding(4, 10, 4, 10) }
            list.addView(cb, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams.MATCH_PARENT, 0.also { }.let { LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).height })
        root.addView(TextView(this).apply { text = "Prototype only — switches do not control Minecraft."; textSize = 12f; setTextColor(Color.YELLOW); setPadding(0, 16, 0, 0) })
        setContentView(root)
    }
}
